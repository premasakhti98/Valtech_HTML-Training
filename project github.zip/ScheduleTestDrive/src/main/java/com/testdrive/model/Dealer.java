package com.testdrive.model;

public class Dealer {

}
